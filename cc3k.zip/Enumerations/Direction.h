#ifndef DIRECTION_H_
#define DIRECTION_H_
enum class Direction {North = 0, NorthWest, West, East, NorthEast, South, SouthEast, SouthWest};

#endif
