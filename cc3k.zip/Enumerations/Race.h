#ifndef _RACE_H_
#define _RACE_H_
enum class Race { Shade, Drow, Vampire, Troll, Goblin, Human, Dwarf, Elf, Orc, 
									Merchant, Dragon, Halfling };
#endif

