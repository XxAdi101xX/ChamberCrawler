#ifndef _POTIONTYPE_H_
#define _POTIONTYPE_H_
enum class PotionType {RestoreHealth = 0, PoisonHealth, BoostAttack, BoostDefence,
											WoundAttack, WoundDefence };
#endif
