#ifndef _CELLTYPE_H_
#define _CELLTYPE_H_

enum class CellType {Wall, FloorTile, DoorWay, Passage, Stairs, Null};

#endif
