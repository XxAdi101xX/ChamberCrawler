#ifndef _ITEMTYPE_H_
#define _ITEMTYPE_H_
enum class ItemType { GoldPile, Potion };
#endif
