#include "Observer.h"

Observer::~Observer(){};
