#ifndef _DWARF_H_
#define _DWARF_H_

#include "Character.h"


class Dwarf final: public Character {
public:
	Dwarf(int wallet); // ctor

};


#endif


