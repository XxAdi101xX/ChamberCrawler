TODO

- Change coordinates to use a different class or pair
- Look at the code with comment //LOOK BACK

- Add floor number to TextDisplay

- Check if the make_shared works properly (does not cause crashes)
